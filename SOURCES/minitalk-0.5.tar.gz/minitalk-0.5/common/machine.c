/*
 * machine.c -- virtual machine state data
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "common.h"
#include "machine.h"


Machine machine;		/* an instance of the virtual machine */
