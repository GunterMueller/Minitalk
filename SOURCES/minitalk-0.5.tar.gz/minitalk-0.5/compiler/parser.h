/*
 * parser.h -- MiniTalk parser
 */


#ifndef _PARSER_H_
#define _PARSER_H_


extern Bool debugParser;


Node *parseMethod(Variable **variables);


#endif /* _PARSER_H_ */
